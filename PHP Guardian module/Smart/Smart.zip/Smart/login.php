<html>
<head>
<title>Login to Smart Money for VITIANS</title>
</head>
<body>

<h1>VIT UNIVERSITY</h1>
<h2>Smart Money Portal System for Guardians</h2>
<form action="checkdb.php" method="POST">
Username: <input type="text" name="uname" /><br />
Password: <input type="password" name="pw" />
<input type="submit" value="Login" />
</form> 

</body>
</html>
